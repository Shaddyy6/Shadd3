--------------------------
File name: Shadd4.exe
Author: Shaddyy
Discord: shaddythebest
Damage rate: Destructive
-------------------------
THE AUTHOR IS NOT RESPONSABLE FOR ANY DAMAGE DONE!